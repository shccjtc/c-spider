﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace spder1._1
{
    class Program
    {
        public class news
        {
            public string theme;
            public string date;
            public string department;
            public string articles = string.Empty;
            public string writer=string.Empty;

            public void addarticles(string str) //增加内容
            {
                this.articles = articles + str;
            }
            public void printinformation(string str)// 获得新闻发布信息
            {
                string[] infosplit = Regex.Split(str, "&nbsp", RegexOptions.IgnoreCase);
                string pattern = @"[\u4e00-\u9fa5]{2,5}";// 正则表达式：只有中文2-5长度
                Console.Write("作者：");
                foreach (Match match in Regex.Matches(infosplit[4], pattern))
                {
                    if (match.Value != "作者"&& match.Value != "编辑" && match.Value != "摄影")
                    {
                        Console.Write(match.Value + " ");
                        this.writer = this.writer + match.Value;
                    }
                }
                Console.WriteLine();

                //Console.WriteLine("作者：" +writer);
                Console.Write("编辑：");
                //Console.WriteLine("12:" + infosplit[12]);
                foreach (Match match in Regex.Matches(infosplit[8], pattern))
                {
                    if (match.Value != "作者" && match.Value != "编辑" && match.Value != "摄影")
                    {
                        Console.Write(match.Value);
                        this.department = match.Value;
                    }
                }
                Console.WriteLine();
                //Console.WriteLine(total_string);
            }

            public void printarticle(string str)  //处理新闻文本信息
            {
                string[] sArrey = Regex.Split(str, "</p>", RegexOptions.IgnoreCase);
                string pattern = @"[\u4e00-\u9fa5]{1,100}|【|】|^\d{n}$ ";// 正则表达式：只有中文1-100长度
                string first_passager = string.Empty;
                foreach (Match match in Regex.Matches(sArrey[0], pattern))
                {
                    Console.Write(match.Value + " ");
                    this.articles = this.articles + match.Value;

                }
                for (int i = 1; i < sArrey.Length; i++)
                {
                    if (sArrey[i].Contains("<p>") && !sArrey[i].Contains("&nbsp;"))
                    {
                        this.articles = this.articles + subStr2(sArrey[i], "<p>") + "\n";
                    }
                    else if (sArrey[i].Contains("<p class=\"vsbcontent_end\">") && !sArrey[i].Contains("<br>") && !sArrey[i].Contains("&nbsp;"))
                    {
                        this.articles = this.articles + subStr2(sArrey[i], "<p class=\"vsbcontent_end\">") + "\n";
                    }

                }
                Console.WriteLine(this.articles);
                //Console.WriteLine(totalstring);
            }
        }
        class file
        {
            public string filepath;
            public string filename;
            public void writefile(news n1)  //写文件
            {
                this.filepath = "C:\\Users\\LEE\\Desktop\\spider\\" + n1.date;
                if (!Directory.Exists(filepath))  //不存在文件夹，创建
                {
                    Directory.CreateDirectory(filepath);  //创建新的文件夹
                }
                FileStream fs = new FileStream(filepath + "\\" + filename + ".txt", FileMode.Create);
                StreamWriter sw = new StreamWriter(fs);
                sw.WriteLine("题目："+n1.theme);
                sw.WriteLine("发布时间：" + n1.date);
                sw.WriteLine("作者：" + n1.writer);
                sw.WriteLine("编辑部门：" + n1.department);
                sw.WriteLine("正文：" + n1.articles);
                //清空缓冲区
                sw.Flush();
                //关闭流
                sw.Close();
                fs.Close();

            }

            public int countfilesbydate(string date) {   //得到同一时间新闻的个数
                
                System.IO.DirectoryInfo dirInfo = new System.IO.DirectoryInfo("C:\\Users\\LEE\\Desktop\\spider\\"+date);
                int totalFile = 0;
                totalFile += dirInfo.GetFiles().Length;
                return totalFile;
            }


        }

        class datedictionary
        {
            Dictionary<string, int> dateDictionary = new Dictionary<string, int>();
            public void adddictionary(news n1)
            {
                if (dateDictionary.ContainsKey(n1.date))
                {
                    dateDictionary[n1.date]++;
                }
                else
                {
                    dateDictionary.Add(n1.date, 1);
                }
            }
            public void outputdictionary()
            {
                string filepath = "C:\\Users\\LEE\\Desktop\\spider\\" ;
                string filename = "everyday";
                if (!Directory.Exists(filepath))  //不存在文件夹，创建
                {
                    Directory.CreateDirectory(filepath);  //创建新的文件夹
                }
                FileStream fs = new FileStream(filepath + "\\" + filename + ".txt", FileMode.Create);
                StreamWriter sw = new StreamWriter(fs);


                foreach (KeyValuePair<string, int> kvp in dateDictionary)
                {
                    Console.WriteLine("时间：{0},数量：{1}", kvp.Key, kvp.Value);
                    sw.WriteLine("{0},{1}", kvp.Key, kvp.Value);
                }
                //清空缓冲区
                sw.Flush();
                //关闭流
                sw.Close();
                fs.Close();
            }
        }

        class departmentdictonary
        {
            Dictionary<string, int> departmentDictionary = new Dictionary<string, int>();
            public void adddictionary(news n1)
            {
                if (departmentDictionary.ContainsKey(n1.department))
                {
                    departmentDictionary[n1.department]++;
                }
                else
                {
                    departmentDictionary.Add(n1.department, 1);
                }
            }

            public void outputdictionary()
            {
                string filepath = "C:\\Users\\LEE\\Desktop\\spider\\";
                string filename = "everydepartment";
                if (!Directory.Exists(filepath))  //不存在文件夹，创建
                {
                    Directory.CreateDirectory(filepath);  //创建新的文件夹
                }
                FileStream fs = new FileStream(filepath + "\\" + filename + ".txt", FileMode.Create);
                StreamWriter sw = new StreamWriter(fs);
                foreach (KeyValuePair<string, int> kvp in departmentDictionary)
                {
                    sw.WriteLine("{0},{1}", kvp.Key, kvp.Value);
                    Console.WriteLine("学院：{0},数量：{1}", kvp.Key, kvp.Value);
                }
                //清空缓冲区
                sw.Flush();
                //关闭流
                sw.Close();
                fs.Close();
            }
        }


        public static string subStr(string str, string startStr, string endStr) //读取startStr和endStr之间的内容
        {
            //Console.Write(startStr.Length);
            int startIndex = str.IndexOf(startStr, 0) + startStr.Length;//得到目标文字第一个字的位置
            //Console.Write(str);
            int endIndex = str.IndexOf(endStr, 0);//得到目标文字最后一字的位置
            //Console.WriteLine(startIndex);
            //Console.WriteLine(endIndex);
            string resultStr = str.Substring(startIndex, endIndex - startIndex);//得到目标文字
            return resultStr;
        }
        public static string subStr2(string str, string startStr) //读取startStr之后的内容
        {
            //Console.Write(startStr.Length);
            int startIndex = str.IndexOf(startStr, 0) + startStr.Length;//得到目标文字第一个字的位置
            //Console.Write(str);
            int endIndex = str.Length;//得到目标文字最后一字的位置
            string resultStr = str.Substring(startIndex, endIndex - startIndex);//得到目标文字
            return resultStr;
        }

        public static string Obdate(string str)  //获得时间
        {
            string[] infosplit = Regex.Split(str, "&nbsp", RegexOptions.IgnoreCase);
            string date = subStr(infosplit[0], ">", "</a>");
            Console.WriteLine("发布时间：" + date);
            return date;
        }


        public static news handleeachpage(string url)
        {
            WebRequest request = WebRequest.Create(url);//访问目标URL
            try
            {
                WebResponse response = (WebResponse)request.GetResponse();//获得响应

                //读取网页中的内容
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream, Encoding.GetEncoding("GB2312"));
                news n1 = new news();
                file f1 = new file();
                //处理网页字符串
                string str;
                string webcontent = string.Empty;
                while ((str = reader.ReadLine()) != null)   //将网页内容放入字符串中
                {
                    webcontent = webcontent + str;
                }
                string theme = subStr(webcontent, "<h2>", "</h2>"); //标题
                Console.WriteLine(theme);//标题
                n1.theme = theme;
           
                string information = subStr(webcontent, "发布日期：", "点击：");
                //Console.WriteLine(information);
                string date = Obdate(information);//获得时间
                n1.date = date;
                n1.printinformation(information); //处理新闻发布信息
                string article = subStr(webcontent, "id=\"vsb_content_2\"", "id=\"div_vote_id\"");
                //Console.WriteLine(article);
                n1.printarticle(article); //处理新闻文本信息
                f1.writefile(n1);
                return n1;

            }
            catch (Exception e)
            {

                Console.WriteLine(url + "该网页不存在");
            }
            return null;
        }
        static void Main(string[] args)
        {
            departmentdictonary d1 = new departmentdictonary();
             datedictionary da1 = new datedictionary();
             for (int i = 43926; i < 46296; i++)
             {
                 int num = i;
                 string url = "https://news.jlu.edu.cn/info/1021/" + num + ".htm";
                 news n1 =handleeachpage(url);
                 if (n1 != null)
                 {
                     if (n1.department != null)
                     {
                         d1.adddictionary(n1);
                     }
                    da1.adddictionary(n1);
                 }
             }
             d1.outputdictionary();
             da1.outputdictionary();
           // string url = "https://news.jlu.edu.cn/info/1021/43956.htm";
           // news n1 = handleeachpage(url);
           // Console.WriteLine(n1.date);
        }
    }
}
