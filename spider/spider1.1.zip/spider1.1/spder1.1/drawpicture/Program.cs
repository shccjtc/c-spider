﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace drawpicture
{
    class Program
    {

        public class date
        {
            public int year;
            public int month;
            public int day;
            public int num;
            public void outdate(string str)
            {
                string[] information = str.Split(',');
                string[] time = information[0].Split('-');
                this.year = int.Parse(time[0]);
                this.month = int.Parse(time[1]);
                this.day = int.Parse(time[2]);
                this.num= int.Parse(information[1]);
            }
        }

        public class department
        {
            public string dep;
            public int num;
            public void outdepartment(string str)
            {
                string[] information = str.Split(',');
                this.dep = information[0];
                this.num = int.Parse(information[1]);
            }
        }

        public static Queue<department> getdepartment()
        {
            string filepath = "C:\\Users\\LEE\\Desktop\\spider\\";
            string filename = "everydepartment";
            FileStream fs = new FileStream(filepath + "\\" + filename + ".txt", FileMode.Open);
            StreamReader sr = new StreamReader(fs);
            Queue<department> de = new Queue<department>();
            string dep;
            while ((dep = sr.ReadLine()) != null)
            {
                department depart = new department();
                depart.outdepartment(dep);
                de.Enqueue(depart);
            }
            return de;
        }

        public static Queue<date> getdate()
        {
            string filepath = "C:\\Users\\LEE\\Desktop\\spider\\";
            string filename = "everyday";
            FileStream fs = new FileStream(filepath + "\\" + filename + ".txt", FileMode.Open);
            StreamReader sr = new StreamReader(fs);
            Queue<date> da = new Queue<date>();
            string dat;
            while ((dat = sr.ReadLine()) != null)
            {
                Console.WriteLine(dat);
                date d = new date();
                d.outdate(dat);
                Console.WriteLine(d.year);
                da.Enqueue(d);
            }
            return da;
        }

        public static void count(Queue<date> d)
        {
            Dictionary<int, int> weekdic = new Dictionary<int, int>();
            Dictionary<int, int> weekdaydic = new Dictionary<int, int>();
            //判断该日期是第几周
            while (d.Count!=0)
            {
                int day = 0;
                date dat = d.Dequeue();
                if (dat.year != 2017)
                {
                    day = (dat.year - 2017) * 365;
                }
                switch (dat.month)
                {
                    case 1:day = day;break;
                    case 2:day = day + 31; break;
                    case 3:day = day + 31 + 28;break;
                    case 4: day = day + 62 + 28; break;
                    case 5: day = day + 92 + 28; break;
                    case 6: day = day + 123 + 28; break;
                    case 7: day = day + 153 + 28; break;
                    case 8: day = day + 184 + 28; break;
                    case 9: day = day + 214 + 28; break;
                    case 10: day = day + 245 + 28; break;
                    case 11: day = day + 275+ 28; break;
                    case 12: day = day + 306 + 28; break;

                }
                day = day + dat.day;
                 int num= (day - 1) / 7+1;
                int dnum = (day - 1) % 7;
                if (dnum == 0)
                {
                    dnum = 7;
                }

                if (weekdic.ContainsKey(num))
                {
                    weekdic[num]++;
                }
                else
                {
                    weekdic.Add(num, 1);
                }


                //weekday有多少

                if (weekdaydic.ContainsKey(dnum))
                {
                    weekdaydic[dnum]++;
                }
                else
                {
                    weekdaydic.Add(dnum, 1);
                }

            }


            string filepath = "C:\\Users\\LEE\\Desktop\\spider\\";
            string filename = "everyweek";
            if (!Directory.Exists(filepath))  //不存在文件夹，创建
            {
                Directory.CreateDirectory(filepath);  //创建新的文件夹
            }
            FileStream fs = new FileStream(filepath + "\\" + filename + ".txt", FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            foreach (KeyValuePair<int, int> kvp in weekdic)
            {
                sw.WriteLine("{0},{1}", kvp.Key, kvp.Value);
                Console.WriteLine("第{0}周：,数量：{1}", kvp.Key, kvp.Value);
            }
            //清空缓冲区
            sw.Flush();
            //关闭流
            sw.Close();
            fs.Close();

            filename = "everyweekday";
            if (!Directory.Exists(filepath))  //不存在文件夹，创建
            {
                Directory.CreateDirectory(filepath);  //创建新的文件夹
            }
             fs = new FileStream(filepath + "\\" + filename + ".txt", FileMode.Create);
            sw = new StreamWriter(fs);
            foreach (KeyValuePair<int, int> kvp in weekdaydic)
            {
                sw.WriteLine("{0},{1}", kvp.Key, kvp.Value);
                Console.WriteLine("周：{0},数量：{1}", kvp.Key, kvp.Value);
            }
            //清空缓冲区
            sw.Flush();
            //关闭流
            sw.Close();
            fs.Close();





        }

        static void Main(string[] args)
        {
            Queue<department> de = getdepartment();
            Queue<date> dat = getdate();
            count(dat);


        }
    }
}
